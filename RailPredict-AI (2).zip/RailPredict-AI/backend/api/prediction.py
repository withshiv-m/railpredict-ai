from fastapi import APIRouter, HTTPException

from backend.schemas import PredictionRequest, SimulateRequest
from backend.services.prediction_service import run_prediction, ModelNotAvailableError
from backend.services.simulation_service import (
    DEMO_TRAINS, tick, build_prediction_record, get_state, generate_alerts_for_state,
)
from ml.predict import load_metrics

router = APIRouter(prefix="/api", tags=["prediction"])


@router.post("/predict")
def predict(payload: PredictionRequest):
    record = payload.model_dump()
    try:
        result = run_prediction(record, explain=True)
    except ModelNotAvailableError as e:
        raise HTTPException(status_code=503, detail=str(e))
    return result


@router.post("/simulate")
def simulate(payload: SimulateRequest):
    """Advance the given demo train's live state by `ticks` steps and return
    the resulting state + fresh AI prediction, powering the Live Simulation
    and What-If features without needing a WebSocket connection."""
    if payload.train_id not in DEMO_TRAINS:
        raise HTTPException(status_code=404, detail=f"Unknown train_id '{payload.train_id}'")

    state = None
    for _ in range(payload.ticks):
        state = tick(payload.train_id)

    try:
        record = build_prediction_record(payload.train_id)
        prediction = run_prediction(record, explain=True)
        alerts = generate_alerts_for_state(payload.train_id, state, prediction)
    except ModelNotAvailableError as e:
        raise HTTPException(status_code=503, detail=str(e))

    return {"train_id": payload.train_id, "state": state, "prediction": prediction, "alerts": alerts}


@router.get("/model/metrics")
def model_metrics():
    metrics = load_metrics()
    if metrics is None:
        raise HTTPException(
            status_code=503,
            detail="No trained model metrics found. Run `python ml/train_model.py`.",
        )
    metrics = dict(metrics)
    metrics["is_demo"] = True
    return metrics
