from datetime import datetime, timezone
from fastapi import APIRouter

from backend.services.simulation_service import (
    DEMO_TRAINS, get_state, build_prediction_record, generate_alerts_for_state,
)
from backend.services.prediction_service import run_prediction, ModelNotAvailableError

router = APIRouter(prefix="/api/alerts", tags=["alerts"])


@router.get("")
def list_alerts():
    """Live-computed alerts across all demo trains based on current state."""
    all_alerts = []
    for train_id in DEMO_TRAINS:
        state = get_state(train_id)
        try:
            record = build_prediction_record(train_id)
            prediction = run_prediction(record)
        except ModelNotAvailableError:
            continue
        alerts = generate_alerts_for_state(train_id, state, prediction)
        for a in alerts:
            a["created_at"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M")
        all_alerts.extend(alerts)

    severity_rank = {"CRITICAL": 0, "HIGH": 1, "MEDIUM": 2, "LOW": 3}
    all_alerts.sort(key=lambda a: severity_rank.get(a["severity"], 4))
    return {"is_demo": True, "alerts": all_alerts}
