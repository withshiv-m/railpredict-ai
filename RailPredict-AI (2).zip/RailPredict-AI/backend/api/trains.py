from fastapi import APIRouter, HTTPException

from backend.services.simulation_service import (
    DEMO_TRAINS, STATION_COORDS, get_state, build_prediction_record,
)
from backend.services.prediction_service import run_prediction, status_from_delay, ModelNotAvailableError

router = APIRouter(prefix="/api/trains", tags=["trains"])


@router.get("")
def list_trains():
    """Return a summary card for every demo train, including a live AI ETA."""
    trains = []
    for train_id, meta in DEMO_TRAINS.items():
        state = get_state(train_id)
        summary = {
            "train_id": train_id,
            "train_number": meta["train_number"],
            "train_name": meta["train_name"],
            "source": meta["source"],
            "destination": meta["destination"],
            "current_station": state["current_station"],
            "next_station": state["next_station"],
            "speed": state["speed"],
            "current_delay": state["current_delay"],
            "distance_remaining": state["distance_remaining"],
            "status": status_from_delay(state["current_delay"]),
        }
        try:
            record = build_prediction_record(train_id)
            pred = run_prediction(record)
            summary["predicted_eta"] = pred["predicted_eta"]
            summary["confidence_score"] = pred["confidence_score"]
        except ModelNotAvailableError:
            summary["predicted_eta"] = None
            summary["confidence_score"] = None
        trains.append(summary)
    return {"is_demo": True, "trains": trains}


@router.get("/{train_id}")
def get_train(train_id: str):
    if train_id not in DEMO_TRAINS:
        raise HTTPException(status_code=404, detail=f"Unknown train_id '{train_id}'")
    meta = DEMO_TRAINS[train_id]
    state = get_state(train_id)

    result = {
        "train_id": train_id,
        "train_number": meta["train_number"],
        "train_name": meta["train_name"],
        "source": meta["source"],
        "destination": meta["destination"],
        "stations": meta["stations"],
        "current_station": state["current_station"],
        "next_station": state["next_station"],
        "speed": state["speed"],
        "current_delay": state["current_delay"],
        "distance_remaining": state["distance_remaining"],
        "congestion_level": state["congestion_level"],
        "rain": state["rain"],
        "temperature": state["temperature"],
        "speed_restriction": bool(state["speed_restriction"]),
        "unscheduled_stop": bool(state["unscheduled_stop"]),
        "is_demo": True,
    }
    try:
        record = build_prediction_record(train_id)
        pred = run_prediction(record, explain=True)
        result["prediction"] = pred
        result["status"] = status_from_delay(state["current_delay"])
    except ModelNotAvailableError as e:
        result["prediction"] = None
        result["status"] = "UNKNOWN"
        result["model_error"] = str(e)
    return result


@router.get("/{train_id}/route")
def get_train_route(train_id: str):
    if train_id not in DEMO_TRAINS:
        raise HTTPException(status_code=404, detail=f"Unknown train_id '{train_id}'")
    meta = DEMO_TRAINS[train_id]
    state = get_state(train_id)

    stations = []
    for name in meta["stations"]:
        lat, lon = STATION_COORDS.get(name, (20.5937, 78.9629))
        stations.append({
            "code": name.replace(" ", "_").upper()[:8],
            "name": name,
            "latitude": lat,
            "longitude": lon,
            "is_current": name == state["current_station"],
        })
    return {"train_id": train_id, "is_demo": True, "stations": stations}
