import os
import numpy as np
import pandas as pd
from fastapi import APIRouter, HTTPException
from sklearn.model_selection import train_test_split

from backend.config import DATA_CSV_PATH
from ml.feature_engineering import load_training_frame
from ml.predict import load_model, ModelNotAvailableError

router = APIRouter(prefix="/api/analytics", tags=["analytics"])


def _bucketize(series: pd.Series, bins: int = 8):
    counts, edges = np.histogram(series.dropna(), bins=bins)
    labels = [f"{edges[i]:.0f}-{edges[i+1]:.0f}" for i in range(len(edges) - 1)]
    return labels, counts.tolist()


@router.get("")
def analytics():
    if not os.path.exists(DATA_CSV_PATH):
        raise HTTPException(
            status_code=503,
            detail="Dataset not found. Run `python scripts/generate_dataset.py`.",
        )
    df = pd.read_csv(DATA_CSV_PATH)

    result = {"is_demo": True}

    # Delay distribution
    labels, counts = _bucketize(df["current_delay"], bins=8)
    result["delay_distribution"] = {"labels": labels, "counts": counts}

    # Average speed per train
    avg_speed = df.groupby("train_number")["speed"].mean().round(1)
    result["average_speed"] = {
        "labels": avg_speed.index.astype(str).tolist(),
        "values": avg_speed.values.tolist(),
    }

    # Weather (rain bucket) vs delay
    df["rain_bucket"] = pd.cut(
        df["rain"], bins=[-0.01, 0.1, 0.3, 0.5, 1.0],
        labels=["No rain", "Light", "Moderate", "Heavy"],
    )
    weather_vs_delay = df.groupby("rain_bucket", observed=True)["current_delay"].mean().round(1)
    result["weather_vs_delay"] = {
        "labels": weather_vs_delay.index.astype(str).tolist(),
        "values": weather_vs_delay.values.tolist(),
    }

    # Congestion vs travel time
    df["congestion_bucket"] = pd.cut(
        df["congestion_level"], bins=[-0.01, 0.25, 0.5, 0.75, 1.0],
        labels=["Low", "Moderate", "High", "Severe"],
    )
    congestion_vs_time = df.groupby("congestion_bucket", observed=True)["remaining_travel_time"].mean().round(1)
    result["congestion_vs_travel_time"] = {
        "labels": congestion_vs_time.index.astype(str).tolist(),
        "values": congestion_vs_time.values.tolist(),
    }

    # Train performance: mean delay per train
    perf = df.groupby("train_name")["current_delay"].mean().round(1).sort_values(ascending=False)
    result["train_performance"] = {
        "labels": perf.index.astype(str).tolist(),
        "values": perf.values.tolist(),
    }

    # Prediction vs actual + ETA error, from the held-out test split of the current model
    try:
        model, columns = load_model()
        X, y = load_training_frame(DATA_CSV_PATH)
        _, X_test, _, y_test = train_test_split(X, y, test_size=0.2, random_state=42)
        preds = model.predict(X_test[columns])
        sample_idx = np.linspace(0, len(y_test) - 1, min(60, len(y_test))).astype(int)
        y_sample = y_test.values[sample_idx]
        p_sample = preds[sample_idx]
        result["prediction_vs_actual"] = {
            "actual": y_sample.round(1).tolist(),
            "predicted": p_sample.round(1).tolist(),
        }
        error = np.abs(y_test.values - preds)
        err_labels, err_counts = _bucketize(pd.Series(error), bins=6)
        result["eta_error_distribution"] = {"labels": err_labels, "counts": err_counts}
    except ModelNotAvailableError:
        result["prediction_vs_actual"] = None
        result["eta_error_distribution"] = None

    return result
