from fastapi import APIRouter, Query

from backend.services.weather_service import get_weather

router = APIRouter(prefix="/api/weather", tags=["weather"])


@router.get("/demo")
def demo_weather(
    latitude: float = Query(default=19.0760),
    longitude: float = Query(default=72.8777),
):
    """Returns current (demo or, if configured, live) weather for a point."""
    return get_weather(latitude, longitude)
