"""
Core prediction service. Wraps the cached ML model (ml/predict.py) and turns
raw feature input into a full PredictionResponse-shaped dict, including the
baseline comparison, calculated ETA timestamps, confidence score, and
optional feature-impact explanations.
"""
from datetime import datetime, timedelta

from ml.predict import (
    load_model,
    predict_remaining_time,
    baseline_remaining_time,
    confidence_score as _confidence_score,
    explain_feature_impacts,
    ModelNotAvailableError,
)
from ml.feature_engineering import build_feature_frame


def run_prediction(record: dict, explain: bool = False, now: datetime = None) -> dict:
    """
    record: dict matching schemas.PredictionRequest fields (train_id may be
    included and is ignored by the model itself).
    """
    now = now or datetime.utcnow()

    try:
        model, columns = load_model()
    except ModelNotAvailableError as e:
        raise

    predicted_minutes = predict_remaining_time(record)
    baseline_minutes = baseline_remaining_time(record)

    X_row = build_feature_frame(record)[columns]
    confidence = _confidence_score(model, X_row)

    predicted_eta_dt = now + timedelta(minutes=predicted_minutes)
    baseline_eta_dt = now + timedelta(minutes=baseline_minutes)
    scheduled_eta_dt = now + timedelta(minutes=record.get("scheduled_travel_time", predicted_minutes))

    delay_prediction = round(
        (predicted_eta_dt - scheduled_eta_dt).total_seconds() / 60.0, 1
    )

    result = {
        "train_id": record.get("train_id", "UNKNOWN"),
        "predicted_remaining_time": round(predicted_minutes, 1),
        "predicted_eta": predicted_eta_dt.strftime("%Y-%m-%d %H:%M"),
        "baseline_eta": baseline_eta_dt.strftime("%Y-%m-%d %H:%M"),
        "scheduled_eta": scheduled_eta_dt.strftime("%Y-%m-%d %H:%M"),
        "delay_prediction": delay_prediction,
        "confidence_score": round(confidence, 1),
        "is_demo": True,
    }

    if explain:
        result["feature_impacts"] = explain_feature_impacts(record, predicted_minutes)

    return result


def status_from_delay(delay_minutes: float) -> str:
    if delay_minutes >= 45:
        return "CRITICAL"
    if delay_minutes >= 10:
        return "DELAYED"
    return "ON TIME"
