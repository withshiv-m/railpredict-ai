"""
In-memory "live" demo state for trains, plus the tick logic that powers the
Live Simulation and What-If features. This intentionally lives in memory
(not the DB) since it represents fast-changing operational state — the DB
still persists trains/stations/predictions/alerts.

DEMO DATA ONLY — not connected to live GPS/NTES/signalling feeds.
"""
import random
from datetime import datetime, timezone

from backend.services.weather_service import get_weather
from backend.services.prediction_service import run_prediction, status_from_delay

DEMO_TRAINS = {
    "TR00001": {
        "train_number": "12123",
        "train_name": "Mumbai - Pune Express",
        "source": "Mumbai CST",
        "destination": "Pune Jn",
        "stations": ["Mumbai CST", "Dadar", "Kalyan", "Karjat", "Lonavala", "Pune Jn"],
        "lat": 18.9398, "lon": 72.8355,
        "scheduled_travel_time": 190,
    },
    "TR00002": {
        "train_number": "11010",
        "train_name": "Deccan Express",
        "source": "Mumbai CST",
        "destination": "Pune Jn",
        "stations": ["Mumbai CST", "Dadar", "Kalyan", "Lonavala", "Pune Jn"],
        "lat": 18.9398, "lon": 72.8355,
        "scheduled_travel_time": 200,
    },
    "TR00003": {
        "train_number": "12010",
        "train_name": "Shatabdi Express",
        "source": "Mumbai Central",
        "destination": "Ahmedabad Jn",
        "stations": ["Mumbai Central", "Borivali", "Vapi", "Surat", "Vadodara", "Ahmedabad Jn"],
        "lat": 18.9693, "lon": 72.8202,
        "scheduled_travel_time": 375,
    },
    "TR00004": {
        "train_number": "12951",
        "train_name": "Mumbai Rajdhani",
        "source": "Mumbai Central",
        "destination": "New Delhi",
        "stations": ["Mumbai Central", "Surat", "Vadodara", "Kota Jn", "New Delhi"],
        "lat": 18.9693, "lon": 72.8202,
        "scheduled_travel_time": 960,
    },
}

STATION_COORDS = {
    "Mumbai CST": (18.9398, 72.8355), "Dadar": (19.0186, 72.8437),
    "Kalyan": (19.2437, 73.1355), "Karjat": (18.9107, 73.3237),
    "Lonavala": (18.7546, 73.4062), "Pune Jn": (18.5286, 73.8744),
    "Mumbai Central": (18.9693, 72.8202), "Borivali": (19.2307, 72.8567),
    "Vapi": (20.3893, 72.9106), "Surat": (21.1959, 72.8302),
    "Vadodara": (22.3072, 73.1812), "Ahmedabad Jn": (23.0272, 72.6019),
    "Kota Jn": (25.1804, 75.8648), "New Delhi": (28.6431, 77.2197),
}

_state = {}


def _init_train_state(train_id: str) -> dict:
    meta = DEMO_TRAINS[train_id]
    rng = random.Random(hash(train_id) % (2 ** 31))
    seg = rng.randint(0, len(meta["stations"]) - 2)
    return {
        "train_id": train_id,
        "current_station": meta["stations"][seg],
        "next_station": meta["stations"][seg + 1],
        "distance_remaining": round(rng.uniform(30, 300), 1),
        "speed": round(rng.uniform(50, 95), 1),
        "current_delay": round(rng.uniform(0, 25), 1),
        "congestion_level": round(rng.uniform(0.1, 0.5), 2),
        "rain": round(rng.uniform(0.0, 0.3), 2),
        "temperature": round(rng.uniform(22, 34), 1),
        "historical_delay": round(rng.uniform(5, 20), 1),
        "previous_train_delay": round(rng.uniform(0, 15), 1),
        "section_average_speed": round(rng.uniform(55, 90), 1),
        "unscheduled_stop": 0,
        "speed_restriction": rng.choice([0, 0, 0, 1]),
        "scheduled_travel_time": meta["scheduled_travel_time"],
    }


def get_state(train_id: str) -> dict:
    if train_id not in DEMO_TRAINS:
        raise KeyError(f"Unknown demo train_id: {train_id}")
    if train_id not in _state:
        _state[train_id] = _init_train_state(train_id)
    return _state[train_id]


def get_all_states() -> dict:
    return {tid: get_state(tid) for tid in DEMO_TRAINS}


def tick(train_id: str) -> dict:
    """Advance one simulated time-step: nudge speed/delay/weather/congestion
    a small random amount so repeated calls show believable drift."""
    state = get_state(train_id)
    rng = random.Random()

    state["speed"] = float(min(max(state["speed"] + rng.uniform(-8, 8), 20), 130))
    state["current_delay"] = float(max(state["current_delay"] + rng.uniform(-2, 4), 0))
    state["congestion_level"] = float(min(max(state["congestion_level"] + rng.uniform(-0.05, 0.08), 0), 1))
    state["distance_remaining"] = float(max(state["distance_remaining"] - state["speed"] / 60.0 * 2, 1))
    state["unscheduled_stop"] = 1 if rng.random() < 0.03 else 0
    state["speed_restriction"] = 1 if rng.random() < 0.1 else state["speed_restriction"]

    lat, lon = STATION_COORDS.get(state["current_station"], (20.0, 75.0))
    weather = get_weather(lat, lon)
    state["temperature"] = weather["temperature"]
    state["rain"] = weather["rain"]

    return state


def hour_and_dow_now():
    now = datetime.now(timezone.utc)
    return now.hour, now.weekday()


def build_prediction_record(train_id: str) -> dict:
    state = get_state(train_id)
    hour, dow = hour_and_dow_now()
    record = dict(state)
    record["hour"] = hour
    record["day_of_week"] = dow
    return record


def generate_alerts_for_state(train_id: str, state: dict, prediction: dict) -> list:
    alerts = []
    if state["current_delay"] >= 45:
        alerts.append({
            "train_id": train_id, "alert_type": "HIGH_DELAY", "severity": "CRITICAL",
            "message": f"Train {train_id} running {state['current_delay']:.0f} min behind schedule.",
        })
    elif state["current_delay"] >= 15:
        alerts.append({
            "train_id": train_id, "alert_type": "HIGH_DELAY", "severity": "HIGH",
            "message": f"Train {train_id} delay increasing: {state['current_delay']:.0f} min.",
        })
    if state["congestion_level"] >= 0.7:
        alerts.append({
            "train_id": train_id, "alert_type": "SEVERE_CONGESTION", "severity": "HIGH",
            "message": f"Severe section congestion detected for {train_id} ({state['congestion_level']*100:.0f}%).",
        })
    if prediction["confidence_score"] < 60:
        alerts.append({
            "train_id": train_id, "alert_type": "LOW_CONFIDENCE", "severity": "MEDIUM",
            "message": f"Low prediction confidence ({prediction['confidence_score']:.0f}%) for {train_id} — conditions are volatile.",
        })
    if state["speed_restriction"]:
        alerts.append({
            "train_id": train_id, "alert_type": "SPEED_RESTRICTION", "severity": "MEDIUM",
            "message": f"Active speed restriction on {train_id}'s current section.",
        })
    if state["rain"] >= 0.5:
        alerts.append({
            "train_id": train_id, "alert_type": "WEATHER_IMPACT", "severity": "MEDIUM",
            "message": f"Heavy rain near {train_id}'s route may extend travel time.",
        })
    return alerts
