"""
Weather service. Real API integration is isolated here so it can be swapped
in later without touching any other file. If WEATHER_API_KEY is absent (the
default for this hackathon prototype), demo weather data is used instead —
and the response is always clearly flagged with is_demo.
"""
import random
from backend.config import WEATHER_API_KEY


def get_weather(latitude: float, longitude: float) -> dict:
    """
    Returns {"temperature": float, "rain": float (0-1), "is_demo": bool}

    If a real WEATHER_API_KEY is configured, this is where an authorized
    provider (e.g. IMD, OpenWeatherMap) call would go. For the hackathon
    prototype, no external call is made — demo data is generated instead.
    """
    if not WEATHER_API_KEY:
        return _demo_weather(latitude, longitude)

    # Placeholder for a real integration. Kept simple and safe: if a key is
    # ever configured but the call fails for any reason, we still fall back
    # to demo data rather than crashing the app.
    try:
        # e.g. httpx.get(f"https://api.weatherprovider.com/v1/current",
        #                params={"lat": latitude, "lon": longitude, "key": WEATHER_API_KEY})
        # Not implemented for the prototype — real providers require a
        # signed agreement / authorized access for railway operational use.
        raise NotImplementedError("Live weather provider not configured for this prototype.")
    except Exception:
        return _demo_weather(latitude, longitude)


def _demo_weather(latitude: float, longitude: float) -> dict:
    rng = random.Random(int((latitude + longitude) * 1000) or 1)
    return {
        "temperature": round(rng.uniform(18, 38), 1),
        "rain": round(rng.uniform(0, 0.6), 2),
        "is_demo": True,
    }
