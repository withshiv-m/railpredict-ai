import { Routes, Route } from "react-router-dom";
import Navbar from "./components/Navbar.jsx";
import Sidebar from "./components/Sidebar.jsx";
import Home from "./pages/Home.jsx";
import Dashboard from "./pages/Dashboard.jsx";
import Trains from "./pages/Trains.jsx";
import TrainDetails from "./pages/TrainDetails.jsx";
import Prediction from "./pages/Prediction.jsx";
import Simulation from "./pages/Simulation.jsx";
import Analytics from "./pages/Analytics.jsx";
import Alerts from "./pages/Alerts.jsx";
import About from "./pages/About.jsx";

export default function App() {
  return (
    <div>
      <Navbar />
      <div className="app-shell">
        <Sidebar />
        <div className="page-body">
          <div className="main-content">
            <Routes>
              <Route path="/" element={<Home />} />
              <Route path="/dashboard" element={<Dashboard />} />
              <Route path="/trains" element={<Trains />} />
              <Route path="/trains/:trainId" element={<TrainDetails />} />
              <Route path="/predict" element={<Prediction />} />
              <Route path="/simulation" element={<Simulation />} />
              <Route path="/analytics" element={<Analytics />} />
              <Route path="/alerts" element={<Alerts />} />
              <Route path="/about" element={<About />} />
            </Routes>
          </div>
        </div>
      </div>
    </div>
  );
}
