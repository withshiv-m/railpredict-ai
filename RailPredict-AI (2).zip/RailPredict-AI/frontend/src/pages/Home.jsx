import { Link } from "react-router-dom";

const FEATURES = [
  { icon: "🤖", title: "AI Prediction", desc: "A trained ML model forecasts remaining travel time from 14 operational features, not a fixed timetable." },
  { icon: "🔄", title: "Dynamic Updates", desc: "ETA recalculates whenever speed, delay, weather or congestion change — live, via the prediction API." },
  { icon: "📊", title: "Confidence Score", desc: "Every prediction ships with a confidence estimate derived from model agreement across the ensemble." },
  { icon: "📉", title: "Delay Analysis", desc: "Baseline vs AI vs scheduled ETA are shown side-by-side so the value of the ML model is transparent." },
];

const HOW_IT_WORKS = [
  "Demo data layer simulates train position, speed, delay, weather and congestion.",
  "Features are engineered and fed into a trained RandomForestRegressor.",
  "The model predicts remaining travel time; ETA = current time + predicted time.",
  "A physics baseline (distance ÷ speed) is computed alongside it for comparison.",
  "Results, confidence and feature impacts are served over a FastAPI backend to the dashboard.",
];

export default function Home() {
  return (
    <div>
      <div className="hero">
        <h1>Predict Train Arrival Time with AI</h1>
        <p>Dynamic ETA forecasting using train movement, delay, weather and operational conditions.</p>
        <div className="hero-buttons">
          <Link to="/predict" className="btn btn-primary">Check Train ETA</Link>
          <Link to="/dashboard" className="btn btn-secondary">Live Dashboard</Link>
          <Link to="/analytics" className="btn btn-secondary">View Prediction Analytics</Link>
        </div>
      </div>

      <div className="grid grid-4 mb-24">
        {FEATURES.map((f) => (
          <div className="card feature-card" key={f.title}>
            <div className="icon">{f.icon}</div>
            <h3>{f.title}</h3>
            <p className="muted text-sm">{f.desc}</p>
          </div>
        ))}
      </div>

      <div className="grid grid-2 gap-16">
        <div className="card">
          <div className="section-title">The Problem</div>
          <p className="text-sm">
            Static timetables don't reflect real operating conditions. Coaching trains face variable
            delays from congestion, weather, speed restrictions and preceding-train knock-on effects —
            a fixed schedule can't capture any of that.
          </p>
        </div>
        <div className="card">
          <div className="section-title">The Solution</div>
          <p className="text-sm">
            RailPredict AI combines a physics-based baseline with a trained machine learning model that
            ingests live operational signals, producing a dynamically updated, explainable ETA with a
            calibrated confidence score.
          </p>
        </div>
      </div>

      <div className="card mt-24">
        <div className="section-title">How It Works</div>
        <ol style={{ paddingLeft: 20, fontSize: 14 }}>
          {HOW_IT_WORKS.map((step, i) => (
            <li key={i} style={{ marginBottom: 8 }}>{step}</li>
          ))}
        </ol>
      </div>

      <div className="card mt-24" style={{ borderColor: "rgba(232,150,60,0.4)", background: "rgba(232,150,60,0.05)" }}>
        <strong>DEMO DATA NOTICE:</strong>{" "}
        <span className="text-sm">
          This is a hackathon prototype. All train positions, delays, weather and GPS-style locations
          are simulated. It is not connected to live Indian Railways / NTES / GPS / signalling systems.
          Backend APIs are designed so authorized real data sources can be plugged in later.
        </span>
      </div>
    </div>
  );
}
