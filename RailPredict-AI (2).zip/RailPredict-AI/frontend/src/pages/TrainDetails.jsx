import { useEffect, useState } from "react";
import { useParams, Link } from "react-router-dom";
import api from "../api.js";
import RouteTimeline from "../components/RouteTimeline.jsx";
import ETACard from "../components/ETACard.jsx";
import PredictionCard from "../components/PredictionCard.jsx";
import StatusBadge from "../components/StatusBadge.jsx";
import MapView from "../components/MapView.jsx";

export default function TrainDetails() {
  const { trainId } = useParams();
  const [train, setTrain] = useState(null);
  const [route, setRoute] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const [trainData, routeData] = await Promise.all([
        api.getTrain(trainId),
        api.getTrainRoute(trainId),
      ]);
      setTrain(trainData);
      setRoute(routeData);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
  }, [trainId]);

  if (loading) return <p className="muted loading-dots">Loading</p>;
  if (error) return <div className="error-box">{error}</div>;
  if (!train) return null;

  return (
    <div>
      <Link to="/trains" className="text-sm muted">← Back to trains</Link>
      <div className="flex-between mt-8 mb-24">
        <div>
          <h1>{train.train_number} · {train.train_name}</h1>
          <p className="muted">{train.source} → {train.destination}</p>
        </div>
        <StatusBadge status={train.status} />
      </div>

      <div className="grid grid-4 mb-24">
        <MiniStat label="Current Speed" value={`${train.speed.toFixed(0)} km/h`} />
        <MiniStat label="Distance Remaining" value={`${train.distance_remaining.toFixed(0)} km`} />
        <MiniStat label="Current Delay" value={`${train.current_delay.toFixed(0)} min`} />
        <MiniStat label="Section Congestion" value={`${(train.congestion_level * 100).toFixed(0)}%`} />
      </div>

      {train.prediction ? (
        <div className="mb-24"><ETACard prediction={train.prediction} /></div>
      ) : (
        <div className="error-box mb-24">
          {train.model_error || "Prediction unavailable — model not trained yet."}
        </div>
      )}

      <div className="grid grid-2 gap-16 mb-24">
        <div className="card">
          <div className="section-title">Route</div>
          <RouteTimeline stations={train.stations} currentStation={train.current_station} />
        </div>
        {route && (
          <div className="card">
            <div className="section-title">Route Map (demo coordinates)</div>
            <MapView stations={route.stations} />
          </div>
        )}
      </div>

      {train.prediction && (
        <PredictionCard prediction={train.prediction} />
      )}
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div className="card stat-card">
      <div className="stat-label">{label}</div>
      <div className="stat-value" style={{ fontSize: 22 }}>{value}</div>
    </div>
  );
}
