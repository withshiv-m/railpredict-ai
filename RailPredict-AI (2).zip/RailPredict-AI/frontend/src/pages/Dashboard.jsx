import { useEffect, useState } from "react";
import api from "../api.js";
import TrainTable from "../components/TrainTable.jsx";

export default function Dashboard() {
  const [trains, setTrains] = useState([]);
  const [metrics, setMetrics] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const [trainsRes, metricsRes] = await Promise.allSettled([
        api.listTrains(),
        api.modelMetrics(),
      ]);
      if (trainsRes.status === "fulfilled") setTrains(trainsRes.value.trains);
      else setError(trainsRes.reason.message);
      if (metricsRes.status === "fulfilled") setMetrics(metricsRes.value);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 15000);
    return () => clearInterval(interval);
  }, []);

  const onTime = trains.filter((t) => t.status === "ON TIME").length;
  const delayed = trains.filter((t) => t.status === "DELAYED").length;
  const critical = trains.filter((t) => t.status === "CRITICAL").length;

  return (
    <div>
      <div className="flex-between mb-24">
        <div>
          <h1>Operations Dashboard</h1>
          <p className="muted">Live-computed demo train monitoring, refreshed every 15 seconds.</p>
        </div>
      </div>

      {error && <div className="error-box mb-24">{error}</div>}

      <div className="grid grid-4 mb-24">
        <div className="card stat-card">
          <div className="stat-label">Total Active Trains</div>
          <div className="stat-value">{trains.length}</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">On Time</div>
          <div className="stat-value" style={{ color: "var(--green)" }}>{onTime}</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">Delayed</div>
          <div className="stat-value" style={{ color: "var(--amber)" }}>{delayed}</div>
        </div>
        <div className="card stat-card">
          <div className="stat-label">High Risk / Critical</div>
          <div className="stat-value" style={{ color: "var(--red)" }}>{critical}</div>
        </div>
      </div>

      <div className="card mb-24">
        <div className="section-title">Model Performance</div>
        {metrics ? (
          <div className="grid grid-3">
            <MiniMetric label="MAE" value={`${metrics.mae} min`} />
            <MiniMetric label="RMSE" value={`${metrics.rmse} min`} />
            <MiniMetric label="R² Score" value={metrics.r2} />
          </div>
        ) : (
          <p className="muted text-sm">Model metrics unavailable — run <code>python ml/train_model.py</code>.</p>
        )}
      </div>

      <div className="card">
        <div className="section-title">Train Monitoring</div>
        {loading ? <p className="muted loading-dots">Loading</p> : <TrainTable trains={trains} />}
      </div>
    </div>
  );
}

function MiniMetric({ label, value }) {
  return (
    <div>
      <div className="stat-label">{label}</div>
      <div className="stat-value" style={{ fontSize: 22 }}>{value}</div>
    </div>
  );
}
