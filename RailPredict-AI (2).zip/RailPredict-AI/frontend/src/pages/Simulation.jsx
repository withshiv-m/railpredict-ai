import { useEffect, useRef, useState } from "react";
import api, { openSimulationSocket } from "../api.js";
import SimulationPanel from "../components/SimulationPanel.jsx";

const DEMO_TRAIN_IDS = ["TR00001", "TR00002", "TR00003", "TR00004"];

const BASE_WHATIF = {
  train_id: "TR00001",
  distance_remaining: 120,
  speed: 68,
  current_delay: 10,
  rain: 0.1,
  temperature: 27,
  hour: 14,
  day_of_week: 3,
  historical_delay: 8,
  congestion_level: 0.3,
  previous_train_delay: 5,
  scheduled_travel_time: 140,
  section_average_speed: 70,
  unscheduled_stop: 0,
  speed_restriction: 0,
};

const SLIDERS = [
  { key: "speed", label: "Current Speed (km/h)", min: 20, max: 130, step: 1 },
  { key: "current_delay", label: "Current Delay (min)", min: 0, max: 120, step: 1 },
  { key: "distance_remaining", label: "Distance Remaining (km)", min: 1, max: 500, step: 1 },
  { key: "rain", label: "Rain (0-1)", min: 0, max: 1, step: 0.05 },
  { key: "congestion_level", label: "Congestion (0-1)", min: 0, max: 1, step: 0.05 },
  { key: "previous_train_delay", label: "Preceding Train Delay (min)", min: 0, max: 120, step: 1 },
];

export default function Simulation() {
  // --- Live simulation (WebSocket) ---
  const [trainId, setTrainId] = useState("TR00001");
  const [running, setRunning] = useState(false);
  const [liveState, setLiveState] = useState(null);
  const [livePrediction, setLivePrediction] = useState(null);
  const [connError, setConnError] = useState(null);
  const socketRef = useRef(null);

  function startSimulation() {
    setConnError(null);
    setLiveState(null);
    setLivePrediction(null);
    const socket = openSimulationSocket(
      trainId,
      (msg) => {
        if (msg.error) {
          setConnError(msg.error);
          return;
        }
        setLiveState(msg.state);
        setLivePrediction(msg.prediction);
      },
      () => setConnError("Simulation connection lost. Make sure the backend is running.")
    );
    socketRef.current = socket;
    setRunning(true);
  }

  function stopSimulation() {
    socketRef.current?.close();
    socketRef.current = null;
    setRunning(false);
  }

  useEffect(() => () => socketRef.current?.close(), []);

  // --- What-if simulator ---
  const [whatif, setWhatif] = useState(BASE_WHATIF);
  const [originalEta, setOriginalEta] = useState(null);
  const [newEta, setNewEta] = useState(null);
  const [whatifError, setWhatifError] = useState(null);
  const debounceRef = useRef(null);

  async function runWhatIf(values, isFirst = false) {
    try {
      const result = await api.predict(values);
      if (isFirst) setOriginalEta(result);
      setNewEta(result);
      setWhatifError(null);
    } catch (e) {
      setWhatifError(e.message);
    }
  }

  useEffect(() => {
    runWhatIf(BASE_WHATIF, true);
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  function updateSlider(key, value) {
    const updated = { ...whatif, [key]: Number(value) };
    setWhatif(updated);
    clearTimeout(debounceRef.current);
    debounceRef.current = setTimeout(() => runWhatIf(updated), 300);
  }

  return (
    <div>
      <h1>Simulation</h1>
      <p className="muted mb-24">
        Two ways to see the "dynamic" part of RailPredict AI: a live-ticking WebSocket feed, and an
        instant What-If simulator you can drag around.
      </p>

      <div className="card mb-24">
        <div className="flex-between mb-16">
          <div className="section-title" style={{ marginBottom: 0 }}>Choose a demo train</div>
          <select
            value={trainId}
            onChange={(e) => {
              setTrainId(e.target.value);
              stopSimulation();
            }}
            style={{ width: 160 }}
          >
            {DEMO_TRAIN_IDS.map((id) => <option key={id} value={id}>{id}</option>)}
          </select>
        </div>
        <SimulationPanel
          running={running}
          onStart={startSimulation}
          onStop={stopSimulation}
          connectionError={connError}
          state={liveState}
          prediction={livePrediction}
        />
      </div>

      <div className="card">
        <div className="section-title">ETA What-If Simulator</div>
        <p className="muted text-sm mb-16">Drag a slider — the AI ETA recalculates automatically.</p>

        {whatifError && <div className="error-box mb-16">{whatifError}</div>}

        <div className="grid grid-2 gap-16">
          <div>
            {SLIDERS.map((s) => (
              <div className="field" key={s.key}>
                <div className="flex-between">
                  <label style={{ marginBottom: 0 }}>{s.label}</label>
                  <span className="text-sm">{whatif[s.key]}</span>
                </div>
                <input
                  type="range"
                  min={s.min}
                  max={s.max}
                  step={s.step}
                  value={whatif[s.key]}
                  onChange={(e) => updateSlider(s.key, e.target.value)}
                />
              </div>
            ))}
          </div>

          <div>
            <div className="card" style={{ background: "var(--bg)" }}>
              <div className="grid grid-2 gap-16 mb-16">
                <div>
                  <div className="stat-label">Original ETA</div>
                  <div className="stat-value" style={{ fontSize: 20 }}>{originalEta?.predicted_eta || "—"}</div>
                </div>
                <div>
                  <div className="stat-label">New ETA</div>
                  <div className="stat-value" style={{ fontSize: 20, color: "var(--accent)" }}>{newEta?.predicted_eta || "—"}</div>
                </div>
              </div>
              {originalEta && newEta && (
                <div className="text-sm">
                  <strong>ETA Difference:</strong>{" "}
                  {(newEta.predicted_remaining_time - originalEta.predicted_remaining_time).toFixed(1)} min
                  {" "}vs. original scenario · confidence {newEta.confidence_score}%
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
