import { useEffect, useState } from "react";
import {
  Chart as ChartJS, CategoryScale, LinearScale, BarElement, LineElement,
  PointElement, Title, Tooltip, Legend,
} from "chart.js";
import { Bar, Line } from "react-chartjs-2";
import api from "../api.js";

ChartJS.register(CategoryScale, LinearScale, BarElement, LineElement, PointElement, Title, Tooltip, Legend);

const chartOptions = {
  responsive: true,
  plugins: { legend: { display: true, position: "top" } },
};

export default function Analytics() {
  const [data, setData] = useState(null);
  const [error, setError] = useState(null);

  useEffect(() => {
    api.analytics().then(setData).catch((e) => setError(e.message));
  }, []);

  if (error) return <div className="error-box">{error}</div>;
  if (!data) return <p className="muted loading-dots">Loading</p>;

  return (
    <div>
      <h1>Prediction Analytics</h1>
      <p className="muted mb-24">Charts computed live from the synthetic dataset and the currently trained model.</p>

      <div className="grid grid-2 gap-16 mb-16">
        {data.prediction_vs_actual && (
          <ChartCard title="Prediction vs Actual (test sample)">
            <Line
              options={chartOptions}
              data={{
                labels: data.prediction_vs_actual.actual.map((_, i) => i + 1),
                datasets: [
                  { label: "Actual (min)", data: data.prediction_vs_actual.actual, borderColor: "#1d6fa5", backgroundColor: "#1d6fa5", tension: 0.2 },
                  { label: "Predicted (min)", data: data.prediction_vs_actual.predicted, borderColor: "#e8963c", backgroundColor: "#e8963c", tension: 0.2 },
                ],
              }}
            />
          </ChartCard>
        )}

        {data.eta_error_distribution && (
          <ChartCard title="ETA Error Distribution">
            <Bar
              options={chartOptions}
              data={{
                labels: data.eta_error_distribution.labels,
                datasets: [{ label: "Count", data: data.eta_error_distribution.counts, backgroundColor: "#1d6fa5" }],
              }}
            />
          </ChartCard>
        )}

        <ChartCard title="Delay Distribution">
          <Bar
            options={chartOptions}
            data={{
              labels: data.delay_distribution.labels,
              datasets: [{ label: "Records", data: data.delay_distribution.counts, backgroundColor: "#c9860a" }],
            }}
          />
        </ChartCard>

        <ChartCard title="Average Speed by Train">
          <Bar
            options={chartOptions}
            data={{
              labels: data.average_speed.labels,
              datasets: [{ label: "Avg Speed (km/h)", data: data.average_speed.values, backgroundColor: "#1e8e5a" }],
            }}
          />
        </ChartCard>

        <ChartCard title="Weather (Rain) vs Delay">
          <Bar
            options={chartOptions}
            data={{
              labels: data.weather_vs_delay.labels,
              datasets: [{ label: "Avg Delay (min)", data: data.weather_vs_delay.values, backgroundColor: "#1d6fa5" }],
            }}
          />
        </ChartCard>

        <ChartCard title="Congestion vs Travel Time">
          <Bar
            options={chartOptions}
            data={{
              labels: data.congestion_vs_travel_time.labels,
              datasets: [{ label: "Avg Remaining Travel Time (min)", data: data.congestion_vs_travel_time.values, backgroundColor: "#c53030" }],
            }}
          />
        </ChartCard>

        <ChartCard title="Train Performance (Avg Delay)">
          <Bar
            options={chartOptions}
            data={{
              labels: data.train_performance.labels,
              datasets: [{ label: "Avg Delay (min)", data: data.train_performance.values, backgroundColor: "#0b2545" }],
            }}
          />
        </ChartCard>
      </div>
    </div>
  );
}

function ChartCard({ title, children }) {
  return (
    <div className="card">
      <div className="section-title">{title}</div>
      {children}
    </div>
  );
}
