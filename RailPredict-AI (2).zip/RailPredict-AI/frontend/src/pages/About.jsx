const PIPELINE = [
  "Data Sources (GPS/telemetry, historical data, weather, signalling, congestion, schedule)",
  "Data Ingestion",
  "Data Cleaning",
  "Feature Engineering",
  "ML Prediction Engine (RandomForestRegressor)",
  "ETA Calculation (current time + predicted remaining time)",
  "FastAPI Backend",
  "React Dashboard",
  "Passengers / Railway Operations",
];

const TECH = [
  { group: "Backend", items: ["Python", "FastAPI", "SQLAlchemy", "SQLite", "Pydantic"] },
  { group: "ML", items: ["Pandas", "NumPy", "Scikit-learn", "Joblib"] },
  { group: "Frontend", items: ["React", "Vite", "Chart.js", "Leaflet"] },
];

export default function About() {
  return (
    <div>
      <h1>About &amp; Architecture</h1>

      <div className="card mb-24">
        <div className="section-title">Smart India Hackathon 2026</div>
        <p className="text-sm"><strong>Problem Statement ID:</strong> 26028</p>
        <p className="text-sm"><strong>Title:</strong> Dynamic Forecast of Expected Time of Arrival (ETA) for Coaching Trains</p>
        <p className="text-sm"><strong>Organization:</strong> Ministry of Railways</p>
        <p className="text-sm"><strong>Theme:</strong> Disaster Management</p>
      </div>

      <div className="card mb-24">
        <div className="section-title">Data &amp; AI Pipeline</div>
        <div className="route-timeline">
          {PIPELINE.map((step, i) => (
            <div className="route-step" key={i}>
              <div style={{ position: "relative" }}>
                <div className="route-dot passed" />
                <div className="route-line" />
              </div>
              <div className="route-name">{step}</div>
            </div>
          ))}
        </div>
      </div>

      <div className="grid grid-3 mb-24">
        {TECH.map((t) => (
          <div className="card" key={t.group}>
            <div className="section-title">{t.group}</div>
            <div className="chip-row">
              {t.items.map((item) => <span className="chip" key={item}>{item}</span>)}
            </div>
          </div>
        ))}
      </div>

      <div className="card" style={{ borderColor: "rgba(232,150,60,0.4)", background: "rgba(232,150,60,0.05)" }}>
        <div className="section-title">Limitations &amp; Live Data Plan</div>
        <p className="text-sm">
          This prototype uses a realistic synthetic data layer for demo trains, weather and positions.
          It is not connected to live Indian Railways / NTES / GPS / signalling data. The backend is
          structured (isolated services, a documented feature contract, and a swappable model factory)
          so that authorized real-time feeds — GPS telemetry, signalling data, an official weather
          provider — can be integrated later without redesigning the API or frontend.
        </p>
      </div>
    </div>
  );
}
