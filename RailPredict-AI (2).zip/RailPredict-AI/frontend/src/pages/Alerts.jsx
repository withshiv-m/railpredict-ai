import { useEffect, useState } from "react";
import api from "../api.js";
import AlertCard from "../components/AlertCard.jsx";

export default function Alerts() {
  const [alerts, setAlerts] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);

  async function load() {
    try {
      const data = await api.alerts();
      setAlerts(data.alerts);
      setError(null);
    } catch (e) {
      setError(e.message);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    load();
    const interval = setInterval(load, 10000);
    return () => clearInterval(interval);
  }, []);

  return (
    <div>
      <h1>Alerts</h1>
      <p className="muted mb-24">Live-computed operational alerts across all demo trains, refreshed every 10 seconds.</p>

      {error && <div className="error-box mb-24">{error}</div>}
      {loading && <p className="muted loading-dots">Loading</p>}

      {!loading && alerts.length === 0 && (
        <div className="empty-state">No active alerts right now — all demo trains look healthy.</div>
      )}

      <div>
        {alerts.map((a, i) => <AlertCard alert={a} key={i} />)}
      </div>
    </div>
  );
}
