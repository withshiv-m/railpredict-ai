import { useEffect, useState } from "react";
import api from "../api.js";
import TrainCard from "../components/TrainCard.jsx";

export default function Trains() {
  const [trains, setTrains] = useState([]);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(true);
  const [query, setQuery] = useState("");

  useEffect(() => {
    api.listTrains()
      .then((data) => setTrains(data.trains))
      .catch((e) => setError(e.message))
      .finally(() => setLoading(false));
  }, []);

  const filtered = trains.filter((t) => {
    const q = query.toLowerCase();
    return (
      t.train_number.toLowerCase().includes(q) ||
      t.train_name.toLowerCase().includes(q) ||
      t.source.toLowerCase().includes(q) ||
      t.destination.toLowerCase().includes(q)
    );
  });

  return (
    <div>
      <h1>Trains</h1>
      <p className="muted mb-24">Search demo trains by number, name, source or destination.</p>

      <div className="field" style={{ maxWidth: 360 }}>
        <input
          type="text"
          placeholder="Search e.g. 12123, Rajdhani, Pune..."
          value={query}
          onChange={(e) => setQuery(e.target.value)}
        />
      </div>

      {error && <div className="error-box mb-24">{error}</div>}
      {loading && <p className="muted loading-dots">Loading</p>}

      <div className="grid grid-3 mt-16">
        {filtered.map((t) => (
          <TrainCard train={t} key={t.train_id} />
        ))}
      </div>

      {!loading && filtered.length === 0 && (
        <div className="empty-state">No trains match your search.</div>
      )}
    </div>
  );
}
