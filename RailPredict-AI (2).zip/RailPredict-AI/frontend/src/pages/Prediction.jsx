import { useState } from "react";
import api from "../api.js";
import ETACard from "../components/ETACard.jsx";
import PredictionCard from "../components/PredictionCard.jsx";

const DEMO_TRAIN_IDS = ["TR00001", "TR00002", "TR00003", "TR00004"];

const DEFAULT_FORM = {
  train_id: "TR00001",
  distance_remaining: 85,
  speed: 68,
  current_delay: 12,
  rain: 0.3,
  temperature: 28,
  hour: 18,
  day_of_week: 2,
  historical_delay: 8,
  congestion_level: 0.5,
  previous_train_delay: 5,
  scheduled_travel_time: 100,
  section_average_speed: 70,
  unscheduled_stop: 0,
  speed_restriction: 0,
};

const NUMERIC_FIELDS = [
  { key: "distance_remaining", label: "Distance Remaining (km)", min: 0, max: 1500, step: 1 },
  { key: "speed", label: "Current Speed (km/h)", min: 0, max: 160, step: 1 },
  { key: "current_delay", label: "Current Delay (min)", min: 0, max: 300, step: 1 },
  { key: "rain", label: "Rain (0-1)", min: 0, max: 1, step: 0.05 },
  { key: "temperature", label: "Temperature (°C)", min: -10, max: 50, step: 1 },
  { key: "hour", label: "Hour of Day (0-23)", min: 0, max: 23, step: 1 },
  { key: "day_of_week", label: "Day of Week (0=Mon)", min: 0, max: 6, step: 1 },
  { key: "historical_delay", label: "Historical Avg Delay (min)", min: 0, max: 300, step: 1 },
  { key: "congestion_level", label: "Congestion Level (0-1)", min: 0, max: 1, step: 0.05 },
  { key: "previous_train_delay", label: "Preceding Train Delay (min)", min: 0, max: 300, step: 1 },
  { key: "scheduled_travel_time", label: "Scheduled Travel Time (min)", min: 1, max: 2000, step: 1 },
  { key: "section_average_speed", label: "Section Avg Speed (km/h)", min: 0, max: 160, step: 1 },
];

export default function Prediction() {
  const [form, setForm] = useState(DEFAULT_FORM);
  const [prediction, setPrediction] = useState(null);
  const [error, setError] = useState(null);
  const [loading, setLoading] = useState(false);

  function update(key, value) {
    setForm((f) => ({ ...f, [key]: value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      const payload = { ...form };
      NUMERIC_FIELDS.forEach((f) => (payload[f.key] = Number(payload[f.key])));
      payload.unscheduled_stop = Number(payload.unscheduled_stop);
      payload.speed_restriction = Number(payload.speed_restriction);
      const result = await api.predict(payload);
      setPrediction(result);
    } catch (err) {
      setError(err.message);
      setPrediction(null);
    } finally {
      setLoading(false);
    }
  }

  return (
    <div>
      <h1>ETA Predictor</h1>
      <p className="muted mb-24">
        Enter (or adjust) operational conditions and call the live prediction API to see the scheduled,
        baseline and AI-predicted ETA side by side.
      </p>

      <div className="grid grid-2 gap-16">
        <form className="card" onSubmit={handleSubmit}>
          <div className="section-title">Train &amp; Conditions</div>

          <div className="field">
            <label>Train</label>
            <select value={form.train_id} onChange={(e) => update("train_id", e.target.value)}>
              {DEMO_TRAIN_IDS.map((id) => (
                <option key={id} value={id}>{id}</option>
              ))}
            </select>
          </div>

          {NUMERIC_FIELDS.map((f) => (
            <div className="field" key={f.key}>
              <label>{f.label}</label>
              <input
                type="number"
                min={f.min}
                max={f.max}
                step={f.step}
                value={form[f.key]}
                onChange={(e) => update(f.key, e.target.value)}
              />
            </div>
          ))}

          <div className="grid grid-2 gap-16">
            <div className="field">
              <label>Unscheduled Stop</label>
              <select value={form.unscheduled_stop} onChange={(e) => update("unscheduled_stop", e.target.value)}>
                <option value={0}>No</option>
                <option value={1}>Yes</option>
              </select>
            </div>
            <div className="field">
              <label>Speed Restriction</label>
              <select value={form.speed_restriction} onChange={(e) => update("speed_restriction", e.target.value)}>
                <option value={0}>No</option>
                <option value={1}>Yes</option>
              </select>
            </div>
          </div>

          <button className="btn btn-primary" type="submit" disabled={loading}>
            {loading ? "Predicting…" : "Predict ETA"}
          </button>
        </form>

        <div>
          {error && <div className="error-box mb-16">{error}</div>}
          {prediction ? (
            <div className="flex" style={{ flexDirection: "column", gap: 16 }}>
              <ETACard prediction={prediction} />
              <PredictionCard prediction={prediction} />
            </div>
          ) : (
            !error && (
              <div className="card empty-state">
                Submit the form to see the AI-predicted ETA here.
              </div>
            )
          )}
        </div>
      </div>
    </div>
  );
}
