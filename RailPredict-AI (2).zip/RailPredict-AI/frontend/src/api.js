const BASE_URL = "/api";

async function request(path, options = {}) {
  const res = await fetch(`${BASE_URL}${path}`, {
    headers: { "Content-Type": "application/json" },
    ...options,
  });
  if (!res.ok) {
    let detail = `Request failed (${res.status})`;
    try {
      const body = await res.json();
      detail = body.detail || detail;
    } catch (_) {
      // ignore parse errors, keep default message
    }
    throw new Error(detail);
  }
  return res.json();
}

export const api = {
  health: () => request("/health"),
  listTrains: () => request("/trains"),
  getTrain: (trainId) => request(`/trains/${trainId}`),
  getTrainRoute: (trainId) => request(`/trains/${trainId}/route`),
  predict: (payload) =>
    request("/predict", { method: "POST", body: JSON.stringify(payload) }),
  simulate: (trainId, ticks = 1) =>
    request("/simulate", {
      method: "POST",
      body: JSON.stringify({ train_id: trainId, ticks }),
    }),
  modelMetrics: () => request("/model/metrics"),
  analytics: () => request("/analytics"),
  alerts: () => request("/alerts"),
  weatherDemo: (lat, lon) => request(`/weather/demo?latitude=${lat}&longitude=${lon}`),
};

export function openSimulationSocket(trainId, onMessage, onError) {
  const protocol = window.location.protocol === "https:" ? "wss" : "ws";
  const socket = new WebSocket(`${protocol}://${window.location.host}/ws/simulation/${trainId}`);
  socket.onmessage = (event) => {
    try {
      onMessage(JSON.parse(event.data));
    } catch (e) {
      onError?.(e);
    }
  };
  socket.onerror = (e) => onError?.(e);
  return socket;
}

export default api;
