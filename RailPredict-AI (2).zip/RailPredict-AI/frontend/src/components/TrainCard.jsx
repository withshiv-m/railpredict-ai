import { Link } from "react-router-dom";
import StatusBadge from "./StatusBadge.jsx";
import ConfidenceBadge from "./ConfidenceBadge.jsx";

export default function TrainCard({ train }) {
  return (
    <Link to={`/trains/${train.train_id}`} className="card feature-card" style={{ display: "block" }}>
      <div className="flex-between mb-8">
        <h3 style={{ margin: 0 }}>{train.train_number} · {train.train_name}</h3>
        <StatusBadge status={train.status} />
      </div>
      <p className="muted text-sm mb-8">{train.source} → {train.destination}</p>
      <div className="grid grid-2 gap-8 text-sm">
        <div><span className="muted">Current:</span> {train.current_station}</div>
        <div><span className="muted">Next:</span> {train.next_station}</div>
        <div><span className="muted">Speed:</span> {train.speed?.toFixed?.(0) ?? train.speed} km/h</div>
        <div><span className="muted">Delay:</span> {train.current_delay?.toFixed?.(0) ?? train.current_delay} min</div>
      </div>
      <div className="flex-between mt-16">
        <span className="text-sm"><strong>AI ETA:</strong> {train.predicted_eta || "—"}</span>
        <ConfidenceBadge score={train.confidence_score} />
      </div>
    </Link>
  );
}
