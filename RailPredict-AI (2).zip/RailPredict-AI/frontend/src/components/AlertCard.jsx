const ICONS = {
  HIGH_DELAY: "⏱",
  SEVERE_CONGESTION: "🚦",
  LOW_CONFIDENCE: "❓",
  SPEED_RESTRICTION: "⚠",
  WEATHER_IMPACT: "🌧",
};

export default function AlertCard({ alert }) {
  return (
    <div className={`alert-item ${alert.severity}`}>
      <div style={{ fontSize: 20 }}>{ICONS[alert.alert_type] || "⚠"}</div>
      <div style={{ flex: 1 }}>
        <div className="flex-between">
          <strong className="text-sm">Train {alert.train_id}</strong>
          <span className="text-xs muted">{alert.created_at}</span>
        </div>
        <div className="text-sm mt-8">{alert.message}</div>
        <div className="chip-row mt-8">
          <span className="chip">{alert.alert_type.replace(/_/g, " ")}</span>
          <span className="chip">{alert.severity}</span>
        </div>
      </div>
    </div>
  );
}
