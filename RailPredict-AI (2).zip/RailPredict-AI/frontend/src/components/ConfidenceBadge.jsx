export default function ConfidenceBadge({ score }) {
  if (score === null || score === undefined) {
    return <span className="badge badge-demo">N/A</span>;
  }
  let cls = "badge-ontime";
  if (score < 60) cls = "badge-critical";
  else if (score < 80) cls = "badge-delayed";
  return <span className={`badge ${cls}`}>{score.toFixed(1)}% confidence</span>;
}
