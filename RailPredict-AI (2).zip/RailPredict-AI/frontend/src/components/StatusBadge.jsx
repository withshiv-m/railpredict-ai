export default function StatusBadge({ status }) {
  const cls =
    status === "CRITICAL" ? "badge-critical" : status === "DELAYED" ? "badge-delayed" : "badge-ontime";
  return <span className={`badge ${cls}`}>{status || "UNKNOWN"}</span>;
}
