import { NavLink } from "react-router-dom";

const links = [
  { to: "/", label: "Home" },
  { to: "/dashboard", label: "Dashboard" },
  { to: "/trains", label: "Trains" },
  { to: "/predict", label: "ETA Predictor" },
  { to: "/simulation", label: "Live Simulation" },
  { to: "/analytics", label: "Analytics" },
  { to: "/alerts", label: "Alerts" },
  { to: "/about", label: "About / Architecture" },
];

export default function Sidebar() {
  return (
    <div className="sidebar">
      <div className="sidebar-heading">Navigate</div>
      {links.map((l) => (
        <NavLink
          key={l.to}
          to={l.to}
          end={l.to === "/"}
          className={({ isActive }) => (isActive ? "active" : "")}
        >
          {l.label}
        </NavLink>
      ))}
    </div>
  );
}
