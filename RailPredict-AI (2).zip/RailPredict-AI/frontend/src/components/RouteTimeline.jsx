export default function RouteTimeline({ stations, currentStation }) {
  if (!stations || stations.length === 0) return null;
  const currentIndex = stations.findIndex((s) => s === currentStation || s.name === currentStation);

  return (
    <div className="route-timeline">
      {stations.map((s, i) => {
        const name = typeof s === "string" ? s : s.name;
        const isCurrent = i === currentIndex;
        const isPassed = i < currentIndex;
        return (
          <div className="route-step" key={name + i}>
            <div style={{ position: "relative" }}>
              <div className={`route-dot ${isCurrent ? "current" : isPassed ? "passed" : ""}`} />
              <div className="route-line" />
            </div>
            <div>
              <div className={`route-name ${isCurrent ? "current" : ""}`}>
                {name} {isCurrent && "· current position"}
              </div>
            </div>
          </div>
        );
      })}
    </div>
  );
}
