export default function ETACard({ prediction }) {
  if (!prediction) return null;
  const { scheduled_eta, baseline_eta, predicted_eta, delay_prediction, confidence_score } = prediction;

  return (
    <div className="card">
      <div className="section-title">ETA Comparison</div>
      <div className="grid grid-3 gap-16">
        <div>
          <div className="stat-label">Scheduled ETA</div>
          <div className="stat-value" style={{ fontSize: 20 }}>{scheduled_eta}</div>
        </div>
        <div>
          <div className="stat-label">Baseline ETA</div>
          <div className="stat-value" style={{ fontSize: 20 }}>{baseline_eta}</div>
          <div className="stat-sub">distance ÷ speed, delay-adjusted</div>
        </div>
        <div>
          <div className="stat-label">AI Predicted ETA</div>
          <div className="stat-value" style={{ fontSize: 20, color: "var(--accent)" }}>{predicted_eta}</div>
          <div className="stat-sub">{confidence_score?.toFixed(1)}% confidence</div>
        </div>
      </div>
      <div className="mt-16 text-sm">
        <strong>Delay vs schedule:</strong>{" "}
        <span style={{ color: delay_prediction > 10 ? "var(--red)" : "var(--green)" }}>
          {delay_prediction > 0 ? "+" : ""}{delay_prediction} min
        </span>
      </div>
    </div>
  );
}
