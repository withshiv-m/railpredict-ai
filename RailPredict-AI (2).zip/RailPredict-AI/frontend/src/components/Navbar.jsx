import { NavLink } from "react-router-dom";

export default function Navbar() {
  return (
    <div className="navbar">
      <NavLink to="/" className="brand">
        <span className="brand-badge">RP</span>
        RailPredict AI
        <span className="demo-pill">DEMO DATA</span>
      </NavLink>
      <div className="navbar-links">
        <NavLink to="/dashboard" className={({ isActive }) => (isActive ? "active" : "")}>Dashboard</NavLink>
        <NavLink to="/predict" className={({ isActive }) => (isActive ? "active" : "")}>Predict ETA</NavLink>
        <NavLink to="/analytics" className={({ isActive }) => (isActive ? "active" : "")}>Analytics</NavLink>
        <NavLink to="/alerts" className={({ isActive }) => (isActive ? "active" : "")}>Alerts</NavLink>
      </div>
    </div>
  );
}
