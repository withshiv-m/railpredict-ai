import { Link } from "react-router-dom";
import StatusBadge from "./StatusBadge.jsx";
import ConfidenceBadge from "./ConfidenceBadge.jsx";

export default function TrainTable({ trains }) {
  if (!trains || trains.length === 0) {
    return <div className="empty-state">No trains to display.</div>;
  }
  return (
    <div className="table-wrap">
      <table>
        <thead>
          <tr>
            <th>Train</th>
            <th>Current</th>
            <th>Next</th>
            <th>Speed</th>
            <th>Delay</th>
            <th>Distance</th>
            <th>AI ETA</th>
            <th>Confidence</th>
            <th>Status</th>
          </tr>
        </thead>
        <tbody>
          {trains.map((t) => (
            <tr key={t.train_id}>
              <td>
                <Link to={`/trains/${t.train_id}`}>
                  <strong>{t.train_number}</strong> <span className="muted">{t.train_name}</span>
                </Link>
              </td>
              <td>{t.current_station}</td>
              <td>{t.next_station}</td>
              <td>{t.speed?.toFixed?.(0) ?? t.speed} km/h</td>
              <td>{t.current_delay?.toFixed?.(0) ?? t.current_delay} min</td>
              <td>{t.distance_remaining?.toFixed?.(0) ?? t.distance_remaining} km</td>
              <td>{t.predicted_eta || "—"}</td>
              <td><ConfidenceBadge score={t.confidence_score} /></td>
              <td><StatusBadge status={t.status} /></td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
