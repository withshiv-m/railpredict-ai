import { useState } from "react";

export default function SimulationPanel({
  running,
  onStart,
  onStop,
  connectionError,
  state,
  prediction,
}) {
  return (
    <div className="card">
      <div className="flex-between mb-16">
        <div className="section-title" style={{ marginBottom: 0 }}>Live Simulation</div>
        {!running ? (
          <button className="btn btn-primary" onClick={onStart}>▶ Start Simulation</button>
        ) : (
          <button className="btn btn-outline" onClick={onStop}>■ Stop Simulation</button>
        )}
      </div>

      {connectionError && (
        <div className="error-box mb-16">{connectionError}</div>
      )}

      {!state && !connectionError && (
        <p className="muted text-sm">
          Start the simulation to see the train's speed, delay, weather and congestion evolve every few
          seconds, with the AI ETA recalculated live over a WebSocket connection.
        </p>
      )}

      {state && (
        <div className="grid grid-4 gap-16 mt-16">
          <MiniStat label="Speed" value={`${state.speed.toFixed(0)} km/h`} />
          <MiniStat label="Delay" value={`${state.current_delay.toFixed(0)} min`} />
          <MiniStat label="Distance left" value={`${state.distance_remaining.toFixed(0)} km`} />
          <MiniStat label="Congestion" value={`${(state.congestion_level * 100).toFixed(0)}%`} />
        </div>
      )}

      {prediction && (
        <div className="mt-24">
          <div className="flex-between">
            <span className="text-sm"><strong>AI ETA:</strong> {prediction.predicted_eta}</span>
            <span className="text-sm muted">confidence {prediction.confidence_score.toFixed(1)}%</span>
          </div>
        </div>
      )}
    </div>
  );
}

function MiniStat({ label, value }) {
  return (
    <div>
      <div className="stat-label">{label}</div>
      <div className="stat-value" style={{ fontSize: 20 }}>{value}</div>
    </div>
  );
}
