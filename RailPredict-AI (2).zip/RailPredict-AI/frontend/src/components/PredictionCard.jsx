export default function PredictionCard({ prediction }) {
  if (!prediction) return null;
  const impacts = prediction.feature_impacts || [];

  return (
    <div className="card">
      <div className="section-title">Why did AI predict this ETA?</div>
      {impacts.length === 0 ? (
        <p className="muted text-sm">No significant feature impacts detected for the current conditions.</p>
      ) : (
        <div>
          {impacts.map((f, i) => (
            <div key={i} className="flex-between mb-8" style={{ borderBottom: "1px solid var(--border)", paddingBottom: 8 }}>
              <span className="text-sm">
                {f.direction === "increase" ? "↓" : "↑"} {f.factor}
              </span>
              <strong style={{ color: f.direction === "increase" ? "var(--red)" : "var(--green)" }}>
                {f.direction === "increase" ? "+" : "-"}{f.minutes} min
              </strong>
            </div>
          ))}
        </div>
      )}
      <p className="text-xs muted mt-16">
        Feature impact estimates, not exact SHAP values — computed by perturbing each input toward a neutral value and observing the model's change in prediction.
      </p>
    </div>
  );
}
