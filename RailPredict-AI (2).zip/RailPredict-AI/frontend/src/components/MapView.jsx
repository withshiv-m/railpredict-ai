import { MapContainer, TileLayer, Marker, Popup, Polyline } from "react-leaflet";
import L from "leaflet";
import iconUrl from "leaflet/dist/images/marker-icon.png";
import iconShadow from "leaflet/dist/images/marker-shadow.png";

const defaultIcon = L.icon({ iconUrl, shadowUrl: iconShadow, iconSize: [25, 41], iconAnchor: [12, 41] });
const currentIcon = L.icon({ iconUrl, shadowUrl: iconShadow, iconSize: [32, 52], iconAnchor: [16, 52] });

export default function MapView({ stations }) {
  if (!stations || stations.length === 0) {
    return <div className="empty-state">No route data available.</div>;
  }
  const positions = stations.map((s) => [s.latitude, s.longitude]);
  const center = positions[Math.floor(positions.length / 2)];

  return (
    <div className="map-container">
      <MapContainer center={center} zoom={6} style={{ height: "100%", width: "100%" }} scrollWheelZoom={false}>
        <TileLayer
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
        />
        <Polyline positions={positions} pathOptions={{ color: "#1d6fa5", weight: 3 }} />
        {stations.map((s) => (
          <Marker key={s.code} position={[s.latitude, s.longitude]} icon={s.is_current ? currentIcon : defaultIcon}>
            <Popup>
              <strong>{s.name}</strong>
              {s.is_current && <div>Current train position (demo)</div>}
            </Popup>
          </Marker>
        ))}
      </MapContainer>
    </div>
  );
}
